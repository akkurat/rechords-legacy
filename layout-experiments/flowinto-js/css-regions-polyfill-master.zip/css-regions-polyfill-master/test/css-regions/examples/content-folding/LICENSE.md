This example doesn't come with a license.

We've asked Chris Coyier (the author of this example) for permission to use his work and he gracefully agreed.


From: Chris Coyier
Date: Tuesday, January 8, 2013 11:50 PM
To: Mihai Corlan <mcorlan@adobe.com>
Subject: Re: Contact Chris [#2677]

Hey Mihai,

1) Absolutely go for it.
2) No license.

I would like to stay up to date with regions so any information you can send me or keep me in the loop about, I'd love that.


---
Chris Coyier
CodePen  |  CSS-Tricks  |  ShopTalk


On Tue, Jan 8, 2013 at 11:24 AM, wrote:
Name *
Mihai Corlan
Email *
mcorlan@adobe.com
Message *
Hey Chris,

I am a developer evangelist with Adobe and I've been working on a polyfill for CSS Regions proposal (this is not public yet so please keep it to yourself for now). Our plan is to release the polyfill with a number of use cases/examples so people can see what they can build with it.

And here comes the request :D. I want to use your example from http://css-tricks.com/content-folding/. I couldn't find any license information for this example. So I have two questions:
1. Is it OK to use your example and distribute a slightly modified version with the polyfill?
2. What license do you want to use for this example?

Thanks for your time and thank you for your effort on working/testing CSS Regions. It has been really helpful for us to have examples created by people outside of Adobe.

cheers,
Mihai